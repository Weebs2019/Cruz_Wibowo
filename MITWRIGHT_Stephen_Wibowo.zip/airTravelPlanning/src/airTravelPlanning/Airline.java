package airTravelPlanning;

public class Airline extends Airport{
	private String airlineName;
	public Airline()
	{
		super();
		airlineName="Blah";
	}
	public Airline(String )

}
