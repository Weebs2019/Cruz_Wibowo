package airTravelPlanning;
import java.util.Scanner;
public class BestWaytoGetfromOrigtoDest {
	public static void main(String[] args)
	{
		Scanner airport = new Scanner(System.in);
		Scanner country = new Scanner(System.in);
		System.out.println("What airport are you flying out of? What country is that airport in"+
		" (Use the three letter country code (i.e. USA, GER,...))?");
		String origCode = airport.next();
		String origCtry = country.next();
		System.out.println("What airport are you flying to? What country is that airport in"+
				" (Use the three letter country code (i.e. USA, GER,...))?");
		String finCode = airport.next();
		String finCtry = country.next();
		if(finCtry == origCtry && origCtry == "USA")
		{
			dom_Direct(origCode,finCtry)
		}
	}
	public static String dom_Direct(String orig_Airport, String dest_Air)
	{
		
	}
	
	public static airlineList()
	

}
