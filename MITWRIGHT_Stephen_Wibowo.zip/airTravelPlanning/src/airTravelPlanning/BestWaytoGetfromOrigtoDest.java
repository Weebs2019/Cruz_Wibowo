package airTravelPlanning;

public class BestWaytoGetfromOrigtoDest {
	public static void main(String[] args)
	{
		
	}

}
